/**
 * Note CRUD, deletion, and reparenting operations.
 * Imports from state.ts, history.ts, and arrows.ts (for connected arrow cleanup).
 */

import type { Note } from '../types/note'
import type { Arrow } from '../types/arrow'
import { createDefaultNote } from '../types/note'
import { history } from './history'
import { deleteSelectedArrows } from './arrows'
import {
  notes,
  arrows,
  currentPage,
  selectedNoteIds,
  selectedArrowIds,
  editingNoteId,
  setEditStartSnapshot,
  selectionArray,
  getRootIds,
  persistNote,
  persistPage,
  deepClone,
  getStorage,
  markNoteDirty,
  markPageDirty,
} from './state'

// ── Note CRUD ──

export async function createNote(
  pos: { x: number; y: number },
  parentNoteId?: string,
  options?: {
    initialText?: string;
    startEditing?: boolean;
    bodyText?: string;
    collapsed?: boolean;
    link?: string;
    nodeType?: string;
  }
): Promise<Note> {
  if (!currentPage.value) throw new Error('No page loaded')

  const storage = getStorage()
  const selBefore = selectionArray()
  const rootIdsBefore = getRootIds()

  // Snapshot parent before
  const parentBefore = parentNoteId ? history.snapshotNote(notes, parentNoteId) : null

  const note = createDefaultNote(currentPage.value.id, pos)
  note.zIndex = currentPage.value.nextZIndex++

  // Set initial text in head section
  if (options?.initialText) {
    note.head.content = {
      type: 'doc',
      content: [{
        type: 'paragraph',
        content: [{ type: 'text', text: options.initialText }]
      }]
    }
  }

  // Set body text
  if (options?.bodyText) {
    note.body.enabled = true
    note.body.content = {
      type: 'doc',
      content: [{
        type: 'paragraph',
        content: [{ type: 'text', text: options.bodyText }]
      }]
    }
  }

  // Set collapsed state
  if (options?.collapsed !== undefined) {
    note.collapsed = options.collapsed
  }

  // Set link
  if (options?.link) {
    note.link = options.link
  }

  // Set node type
  if (options?.nodeType) {
    note.nodeType = options.nodeType
  }

  const saved = await storage.saveNote(note)
  notes.set(saved.id, saved)

  if (parentNoteId) {
    const parent = notes.get(parentNoteId)
    if (parent) {
      parent.container.childIds.push(saved.id)
      await persistNote(parent)
    }
  } else {
    currentPage.value.rootNoteIds.push(saved.id)
    await persistPage()
  }

  // Select and optionally edit the new note
  selectedNoteIds.clear()
  selectedArrowIds.clear()
  selectedNoteIds.add(saved.id)

  const shouldEdit = options?.startEditing !== false
  if (shouldEdit) {
    editingNoteId.value = saved.id
    setEditStartSnapshot(deepClone(saved))
  }

  // Build undo action
  const notesBefore: Record<string, Note | null> = { [saved.id]: null }
  const notesAfter: Record<string, Note | null> = { [saved.id]: deepClone(saved) }

  if (parentNoteId) {
    notesBefore[parentNoteId] = parentBefore
    notesAfter[parentNoteId] = history.snapshotNote(notes, parentNoteId)
  }

  history.pushAction({
    description: 'Create note',
    notesBefore,
    notesAfter,
    rootIdsBefore: parentNoteId ? null : rootIdsBefore,
    rootIdsAfter: parentNoteId ? null : getRootIds(),
    selectionBefore: selBefore,
    selectionAfter: [saved.id],
  })

  return saved
}

export async function updateNote(note: Note) {
  const storage = getStorage()
  note.updatedAt = Date.now()
  notes.set(note.id, note)
  await storage.saveNote(note)
  if (currentPage.value) {
    currentPage.value.updatedAt = Date.now()
    await storage.savePage(currentPage.value)
  }
}

// ── History helpers ──

/**
 * Record a move action for notes that were dragged.
 * Call this AFTER the drag completes with before/after positions.
 */
export function pushMoveAction(movedNotes: Array<{ id: string; before: Note; after: Note }>) {
  if (movedNotes.length === 0) return

  const notesBefore: Record<string, Note | null> = {}
  const notesAfter: Record<string, Note | null> = {}
  const sel = movedNotes.map(m => m.id)

  for (const m of movedNotes) {
    notesBefore[m.id] = m.before
    notesAfter[m.id] = m.after
  }

  history.pushAction({
    description: 'Move note' + (movedNotes.length > 1 ? 's' : ''),
    notesBefore,
    notesAfter,
    rootIdsBefore: null,
    rootIdsAfter: null,
    selectionBefore: sel,
    selectionAfter: sel,
  })
}

/**
 * Record a resize action.
 */
export function pushResizeAction(noteId: string, before: Note, after: Note) {
  history.pushAction({
    description: 'Resize note',
    notesBefore: { [noteId]: before },
    notesAfter: { [noteId]: after },
    rootIdsBefore: null,
    rootIdsAfter: null,
    selectionBefore: [noteId],
    selectionAfter: [noteId],
  })
}

/**
 * Record a generic note property change (context menu toggles, color, etc.)
 */
export function pushNotePropertyAction(noteId: string, before: Note, description: string) {
  const after = history.snapshotNote(notes, noteId)
  history.pushAction({
    description,
    notesBefore: { [noteId]: before },
    notesAfter: { [noteId]: after },
    rootIdsBefore: null,
    rootIdsAfter: null,
    selectionBefore: [noteId],
    selectionAfter: [noteId],
  })
}

// ── Deletion ──

export async function deleteNote(noteId: string, parentNoteId?: string) {
  if (!currentPage.value) return

  const storage = getStorage()
  const selBefore = selectionArray()
  const arrowSelBefore = Array.from(selectedArrowIds)
  const rootIdsBefore = getRootIds()

  // Snapshot all notes that will be deleted (including descendants)
  const allIds = history.collectDescendantIds(notes, noteId)
  const notesBefore = history.snapshotNotes(notes, allIds)
  const notesAfter: Record<string, Note | null> = {}
  for (const id of allIds) notesAfter[id] = null

  // Collect arrows connected to any deleted note
  const arrowsToDelete: string[] = []
  const arrowsBefore: Record<string, Arrow | null> = {}
  const arrowsAfterMap: Record<string, Arrow | null> = {}
  for (const arrow of arrows.values()) {
    if (allIds.includes(arrow.sourceNoteId) || allIds.includes(arrow.targetNoteId)) {
      arrowsToDelete.push(arrow.id)
      arrowsBefore[arrow.id] = deepClone(arrow)
      arrowsAfterMap[arrow.id] = null
    }
  }

  // Snapshot parent
  if (parentNoteId) {
    notesBefore[parentNoteId] = history.snapshotNote(notes, parentNoteId)
  }

  // Perform delete
  editingNoteId.value = null
  setEditStartSnapshot(null)

  if (parentNoteId) {
    const parent = notes.get(parentNoteId)
    if (parent) {
      parent.container.childIds = parent.container.childIds.filter(id => id !== noteId)
      await persistNote(parent)
    }
  } else {
    currentPage.value.rootNoteIds = currentPage.value.rootNoteIds.filter(id => id !== noteId)
    await persistPage()
  }

  for (const id of allIds) {
    notes.delete(id)
    selectedNoteIds.delete(id)
  }
  await storage.deleteNotes(allIds)

  // Delete connected arrows
  for (const aid of arrowsToDelete) {
    arrows.delete(aid)
    selectedArrowIds.delete(aid)
  }
  if (arrowsToDelete.length > 0) {
    await storage.deleteArrows(arrowsToDelete)
  }

  // Snapshot parent after
  if (parentNoteId) {
    notesAfter[parentNoteId] = history.snapshotNote(notes, parentNoteId)
  }

  history.pushAction({
    description: 'Delete note',
    notesBefore,
    notesAfter,
    arrowsBefore,
    arrowsAfter: arrowsAfterMap,
    rootIdsBefore: parentNoteId ? null : rootIdsBefore,
    rootIdsAfter: parentNoteId ? null : getRootIds(),
    selectionBefore: selBefore,
    selectionAfter: [],
    arrowSelectionBefore: arrowSelBefore,
    arrowSelectionAfter: [],
  })
}

export async function deleteSelected() {
  if (selectedNoteIds.size === 0) return
  if (!currentPage.value) return

  const storage = getStorage()
  const selBefore = selectionArray()
  const arrowSelBefore = Array.from(selectedArrowIds)
  const rootIdsBefore = getRootIds()

  // Collect ALL notes to delete and their parents
  const allDeleteIds: string[] = []
  const parentSnapshots: Record<string, Note | null> = {}

  const ids = Array.from(selectedNoteIds)

  for (const noteId of ids) {
    if (!notes.has(noteId)) continue
    const descendantIds = history.collectDescendantIds(notes, noteId)
    allDeleteIds.push(...descendantIds)

    const parentId = findParent(noteId)
    if (parentId && !parentSnapshots[parentId]) {
      parentSnapshots[parentId] = history.snapshotNote(notes, parentId)
    }
  }

  const uniqueDeleteIds = [...new Set(allDeleteIds)]

  // Snapshot notes before
  const notesBefore: Record<string, Note | null> = {
    ...history.snapshotNotes(notes, uniqueDeleteIds),
    ...parentSnapshots,
  }
  const notesAfter: Record<string, Note | null> = {}
  for (const id of uniqueDeleteIds) notesAfter[id] = null

  // Collect arrows connected to deleted notes
  const arrowsToDelete: string[] = []
  const arrowsBefore: Record<string, Arrow | null> = {}
  const arrowsAfterMap: Record<string, Arrow | null> = {}
  for (const arrow of arrows.values()) {
    if (uniqueDeleteIds.includes(arrow.sourceNoteId) || uniqueDeleteIds.includes(arrow.targetNoteId)) {
      arrowsToDelete.push(arrow.id)
      arrowsBefore[arrow.id] = deepClone(arrow)
      arrowsAfterMap[arrow.id] = null
    }
  }

  // Perform deletions
  editingNoteId.value = null
  setEditStartSnapshot(null)

  for (const noteId of ids) {
    if (!notes.has(noteId)) continue
    const parentId = findParent(noteId)

    if (parentId) {
      const parent = notes.get(parentId)
      if (parent) {
        parent.container.childIds = parent.container.childIds.filter(id => id !== noteId)
        await persistNote(parent)
      }
    } else {
      currentPage.value!.rootNoteIds = currentPage.value!.rootNoteIds.filter(id => id !== noteId)
    }

    const descendantIds = history.collectDescendantIds(notes, noteId)
    for (const id of descendantIds) {
      notes.delete(id)
      selectedNoteIds.delete(id)
    }
    await storage.deleteNotes(descendantIds)
  }

  // Delete connected arrows
  for (const aid of arrowsToDelete) {
    arrows.delete(aid)
    selectedArrowIds.delete(aid)
  }
  if (arrowsToDelete.length > 0) await storage.deleteArrows(arrowsToDelete)

  await persistPage()

  // Snapshot parents after
  for (const parentId of Object.keys(parentSnapshots)) {
    notesAfter[parentId] = history.snapshotNote(notes, parentId)
  }

  history.pushAction({
    description: 'Delete notes',
    notesBefore,
    notesAfter,
    arrowsBefore: arrowsBefore,
    arrowsAfter: arrowsAfterMap,
    rootIdsBefore,
    rootIdsAfter: getRootIds(),
    selectionBefore: selBefore,
    selectionAfter: [],
    arrowSelectionBefore: arrowSelBefore,
    arrowSelectionAfter: [],
  })
}

/** Delete all currently selected notes AND arrows */
export async function deleteAllSelected() {
  // Delete selected arrows first
  if (selectedArrowIds.size > 0) {
    await deleteSelectedArrows()
  }
  // Then delete selected notes (which also cleans up their arrows)
  if (selectedNoteIds.size > 0) {
    await deleteSelected()
  }
}

// ── Reparenting ──

export async function reparentNote(noteId: string, oldParentNoteId: string | undefined, newParentNoteId: string) {
  if (!currentPage.value) return
  const note = notes.get(noteId)
  if (!note) return

  const selBefore = selectionArray()
  const rootIdsBefore = getRootIds()

  // Snapshot before
  const affectedIds = [noteId]
  if (oldParentNoteId) affectedIds.push(oldParentNoteId)
  affectedIds.push(newParentNoteId)
  const notesBefore = history.snapshotNotes(notes, [...new Set(affectedIds)])

  // Perform reparent
  if (oldParentNoteId) {
    const oldParent = notes.get(oldParentNoteId)
    if (oldParent) {
      oldParent.container.childIds = oldParent.container.childIds.filter(id => id !== noteId)
      await persistNote(oldParent)
    }
  } else {
    currentPage.value.rootNoteIds = currentPage.value.rootNoteIds.filter(id => id !== noteId)
    await persistPage()
  }

  const newParent = notes.get(newParentNoteId)
  if (newParent) {
    if (!newParent.container.enabled) newParent.container.enabled = true
    newParent.container.childIds.push(noteId)
    if (!newParent.container.spatial) {
      note.pos = { x: 0, y: 0 }
      note.width = 'auto'
      note.height = 'auto'
    }
    await persistNote(newParent)
    await persistNote(note)
  }

  const notesAfter = history.snapshotNotes(notes, [...new Set(affectedIds)])

  history.pushAction({
    description: 'Move note to container',
    notesBefore,
    notesAfter,
    rootIdsBefore: oldParentNoteId ? null : rootIdsBefore,
    rootIdsAfter: oldParentNoteId ? null : getRootIds(),
    selectionBefore: selBefore,
    selectionAfter: [noteId],
  })
}

export async function unparentNote(noteId: string, parentNoteId: string, worldPos: { x: number; y: number }) {
  if (!currentPage.value) return
  const note = notes.get(noteId)
  if (!note) return

  const selBefore = selectionArray()
  const rootIdsBefore = getRootIds()
  const notesBefore = history.snapshotNotes(notes, [noteId, parentNoteId])

  // Perform unparent
  const parent = notes.get(parentNoteId)
  if (parent) {
    parent.container.childIds = parent.container.childIds.filter(id => id !== noteId)
    await persistNote(parent)
  }

  note.pos = worldPos
  currentPage.value.rootNoteIds.push(noteId)
  await persistPage()
  await persistNote(note)

  const notesAfter = history.snapshotNotes(notes, [noteId, parentNoteId])

  history.pushAction({
    description: 'Move note to canvas',
    notesBefore,
    notesAfter,
    rootIdsBefore,
    rootIdsAfter: getRootIds(),
    selectionBefore: selBefore,
    selectionAfter: [noteId],
  })
}

export function findParent(noteId: string): string | undefined {
  for (const [id, note] of notes) {
    if (note.container.childIds.includes(noteId)) return id
  }
  return undefined
}
