/**
 * Shared reactive state, storage accessor, and low-level helpers.
 * This is the foundation that all other store modules import from.
 * No store module imports should appear here — only Vue, types, and history.
 */

import { reactive, ref, computed, toRaw, nextTick } from 'vue'
import type { Note } from '../types/note'
import type { Arrow } from '../types/arrow'
import type { Page, PageSummary } from '../types/page'
import type { StorageBackend } from '../storage/interface'

// ── Storage ──

let storage: StorageBackend

export function setStorage(backend: StorageBackend) {
  storage = backend
}

export function getStorage(): StorageBackend {
  return storage
}

// ── Helpers ──

export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(toRaw(obj)))
}

// ── Reactive state ──

export const currentPageId = ref<string | null>(null)
export const currentPage = ref<Page | null>(null)
export const notes = reactive<Map<string, Note>>(new Map())
export const arrows = reactive<Map<string, Arrow>>(new Map())
export const pageList = ref<PageSummary[]>([])
export const pageHistory = ref<string[]>([])
export const loading = ref(false)

// Bumped on every drag frame to force arrow recomputation
export const dragTick = ref(0)

// Direct callback for arrow recomputation — set by ArrowLayer
let arrowRecomputeCallback: (() => void) | null = null

export function setArrowRecompute(fn: () => void) {
  arrowRecomputeCallback = fn
}

export function triggerArrowRecompute() {
  dragTick.value++
  // nextTick ensures Vue has flushed DOM, rAF ensures browser has laid out
  nextTick(() => {
    requestAnimationFrame(() => {
      if (arrowRecomputeCallback) arrowRecomputeCallback()
    })
  })
}

// Selection & editing
export const selectedNoteIds = reactive(new Set<string>())
export const selectedArrowIds = reactive(new Set<string>())
export const editingNoteId = ref<string | null>(null)

// Snapshot of note being edited (captured on edit start, used to build undo on edit end)
export let editStartSnapshot: Note | null = null

export function setEditStartSnapshot(snapshot: Note | null) {
  editStartSnapshot = snapshot
}

// ── Computed ──

export const rootNotes = computed(() => {
  if (!currentPage.value) return []
  return currentPage.value.rootNoteIds
    .map(id => notes.get(id))
    .filter((n): n is Note => n !== undefined)
})

export const selectedNotes = computed(() => {
  return Array.from(selectedNoteIds)
    .map(id => notes.get(id))
    .filter((n): n is Note => n !== undefined)
})

// ── Internal helpers ──

export function getRootIds(): string[] {
  return currentPage.value ? [...currentPage.value.rootNoteIds] : []
}

export function selectionArray(): string[] {
  return Array.from(selectedNoteIds)
}

export async function persistNote(note: Note) {
  note.updatedAt = Date.now()
  await storage.saveNote(note)
}

export async function persistPage() {
  if (currentPage.value) {
    currentPage.value.updatedAt = Date.now()
    await storage.savePage(currentPage.value)
  }
}

// ── Batched save system ──

const dirtyNoteIds = new Set<string>()
const dirtyPage = ref(false)
export const hasPendingSaves = ref(false)
let _saveBatchTimer: ReturnType<typeof setTimeout> | null = null

function scheduleSave(delay = 300) {
  hasPendingSaves.value = true
  if (_saveBatchTimer) clearTimeout(_saveBatchTimer)
  _saveBatchTimer = setTimeout(() => flushPendingSaves(), delay)
}

export function markNoteDirty(note: Note, delay = 300) {
  dirtyNoteIds.add(note.id)
  scheduleSave(delay)
}

export function markPageDirty(delay = 300) {
  dirtyPage.value = true
  scheduleSave(delay)
}

export async function flushPendingSaves() {
  if (_saveBatchTimer) { clearTimeout(_saveBatchTimer); _saveBatchTimer = null }

  // Flush dirty notes
  if (dirtyNoteIds.size > 0) {
    const notesToSave: Note[] = []
    for (const id of dirtyNoteIds) {
      const note = notes.get(id)
      if (note) {
        note.updatedAt = Date.now()
        notesToSave.push(toRaw(note))
      }
    }
    dirtyNoteIds.clear()
    if (notesToSave.length > 0) {
      await storage.saveNotes(notesToSave)
    }
  }

  // Flush dirty page
  if (dirtyPage.value && currentPage.value) {
    currentPage.value.updatedAt = Date.now()
    await storage.savePage(toRaw(currentPage.value))
    dirtyPage.value = false
  }

  hasPendingSaves.value = false
}

// ── Z-index ──

export function bringToTop(note: Note) {
  if (!currentPage.value) return
  note.zIndex = currentPage.value.nextZIndex++
  markNoteDirty(note)
  markPageDirty()
}
